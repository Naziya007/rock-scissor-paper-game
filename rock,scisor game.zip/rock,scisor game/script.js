let userscore=0;
let compscore=0;
const userscorepara=document.querySelector("#user-score");
const compscorepara=document.querySelector("#comp-score");


const choices=document.querySelectorAll(".choice");
const msg=document.querySelector("#msg");
const gencompchoice=()=> {
    const option=["Rock","paper","Scissor"];
    const randidx=Math.floor(Math.random()*3);
    return option[randidx];
}
const drawgame=()=>{
    // console.log("game was draw");
    msg.innerText="Game was Draw ";
    
    msg.style.backgroundColor="black";
}
const showinner=(userwin,userchoice,compchoice)=>{
    if(userwin){
        // console.log("you win!");
        userscore++;
        userscorepara.innerText=userscore;
        msg.innerText=`You Win!  Your ${userchoice} beats ${compchoice}`;

        msg.style.backgroundColor="green";


    }else{
        compscore++;
        compscorepara.innerText=compscore;
        // console.log("you loss!");
        msg.innerText=`You Lose!  ${compchoice} beats your ${userchoice} `;
        msg.style.backgroundColor="red";

    }
}
const playgame=(userchoice)=>{
    console.log("user choice=",userchoice);
    const compchoice=gencompchoice();
    console.log("comp choice=",compchoice);
    if(userchoice===compchoice){
        drawgame();

    }
    else{
        let userwin=true;
        if(userchoice==="Rock"){
            userwin=compchoice==="paper"?false:true;

        }
        else if(userchoice==="paper"){
            userwin=compchoice==="Scissor"?false:true;
        }
        else{
            userwin=compchoice==="rock"?false:true;
        }
        showinner(userwin,userchoice,compchoice);
        } 
    };

choices.forEach((choice) => {
    console.log(choice);
    choice.addEventListener("click",()=>{
        const userchoice=choice.getAttribute("id");
// console.log("choice was clicked",userchoice);
playgame(userchoice);

});
});



